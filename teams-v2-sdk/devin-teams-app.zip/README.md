# Teams App Package


1. **Azure Bot Registration**:
   - Go to Azure Portal and create a new Azure Bot resource
   - Note the Bot ID and App Password
   - Set messaging endpoint to your deployed bot URL

2. **Environment Configuration**:
   Create a .env file with:
   ```
   BOT_ID=your-bot-id-from-azure
   BOT_PASSWORD=your-bot-password-from-azure
   DEVIN_API_KEY=your-devin-api-key
   GITHUB_TOKEN=your-github-token
   ```

3. **Update Manifest**:
   - Replace ${{BOT_ID}} with your actual Bot ID
   - Replace ${{TEAMS_APP_ID}} with a unique app ID
   - Update validDomains with your bot domain

4. **Install in Teams**:
   - Zip the manifest.json and icon files
   - Upload to Teams via Apps → Manage your apps → Upload an app

For more details, see the full documentation.
