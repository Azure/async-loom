# Installation Guide


1. **Extract this zip file** to a temporary location
2. **Open Visual Studio Code**
3. **Open Command Palette** (`Ctrl+Shift+P` or `Cmd+Shift+P`)
4. **Type** "Extensions: Install from VSIX..."
5. **Navigate** to the extracted folder and select the extension files
6. **Restart** VS Code when prompted


1. **Copy the extension folder** to your VS Code extensions directory:
   - **Windows**: `%USERPROFILE%\.vscode\extensions\agunblock-copilot-extension`
   - **macOS**: `~/.vscode/extensions/agunblock-copilot-extension`
   - **Linux**: `~/.vscode/extensions/agunblock-copilot-extension`
2. **Restart** Visual Studio Code
3. **Verify installation** by checking the Extensions panel


1. **Open Command Palette** (`Ctrl+Shift+P`)
2. **Type** "AgUnblock: Configure Agent Settings"
3. **Enter your AgUnblock API key** (get one at https://agunblock.com)
4. **Select your preferred agent type**
5. **Start the background agent** with "AgUnblock: Start Background Agent"


- **Extension not appearing**: Check that all files were copied correctly
- **Commands not working**: Restart VS Code and check the Output panel for errors
- **API key issues**: Verify your key at https://agunblock.com/dashboard

For support, visit: https://agunblock.com/support
