# AgUnblock GitHub Copilot Extension

Enhance your development workflow with background AI agents that integrate seamlessly with GitHub Copilot in Visual Studio Code.

## Features

- **Background Agent Integration**: Run AI agents in the background while you code
- **GitHub Copilot Enhancement**: Augment GitHub Copilot with additional AI capabilities
- **Multiple Agent Types**: Support for Codex, GitHub Copilot, Devin, and Replit agents
- **Automatic Code Analysis**: Continuous monitoring and optimization suggestions
- **Workflow Automation**: Streamline development tasks with intelligent automation

## Installation

### Option 1: Install from VSIX (Recommended)

1. **Download** the extension package from AgUnblock
2. **Open Visual Studio Code**
3. **Open Command Palette** (`Ctrl+Shift+P` or `Cmd+Shift+P`)
4. **Type** "Extensions: Install from VSIX..."
5. **Select** the downloaded `.vsix` file
6. **Restart** VS Code when prompted

### Option 2: Manual Installation

1. **Extract** the downloaded zip file
2. **Copy** the extension folder to your VS Code extensions directory:
   - **Windows**: `%USERPROFILE%\.vscode\extensions\`
   - **macOS**: `~/.vscode/extensions/`
   - **Linux**: `~/.vscode/extensions/`
3. **Restart** Visual Studio Code

## Configuration

### Initial Setup

1. **Open Command Palette** (`Ctrl+Shift+P`)
2. **Type** "AgUnblock: Configure Agent Settings"
3. **Select your preferred agent type**:
   - **GitHub Copilot**: Enhanced code assistance with background processing
   - **Codex**: OpenAI Codex for advanced code generation
   - **Devin**: Autonomous software engineer capabilities
   - **Replit Agent**: Cloud-based development assistance
4. **Enter your AgUnblock API key** when prompted
5. **Choose auto-start preference**

### Settings

Configure the extension through VS Code settings:

```json
{
  "agunblock.apiKey": "your-api-key-here",
  "agunblock.agentType": "copilot",
  "agunblock.autoStart": false
}
```

## Usage

### Starting the Agent

1. **Click** the AgUnblock status bar item (bottom right)
2. **Or use Command Palette**: "AgUnblock: Start Background Agent"
3. **Monitor status** via the status bar indicator

### Available Commands

- `AgUnblock: Start Background Agent` - Activate the background agent
- `AgUnblock: Configure Agent Settings` - Modify agent configuration
- `AgUnblock: View Agent Status` - Display detailed status information

### Status Indicators

- 🤖 **AgUnblock: Inactive** - Agent not running
- ⏳ **AgUnblock: Starting...** - Agent initialization in progress
- ✅ **AgUnblock: Active** - Agent running and monitoring
- ❌ **AgUnblock: Error** - Agent encountered an issue

## Features in Detail

### Background Code Analysis

The extension continuously monitors your active editor and provides:

- **Real-time code quality analysis**
- **Performance optimization suggestions**
- **Security vulnerability detection**
- **Best practice recommendations**

### GitHub Copilot Integration

Enhances GitHub Copilot with:

- **Context-aware suggestions** based on your project structure
- **Advanced code completion** using multiple AI models
- **Intelligent refactoring** recommendations
- **Automated documentation** generation

### Workflow Automation

Automates common development tasks:

- **Code review preparation**
- **Test case generation**
- **Documentation updates**
- **Dependency management**

## API Key Setup

To use the AgUnblock extension, you need an API key:

1. **Visit** [AgUnblock Platform](https://agunblock.com)
2. **Sign up** for an account
3. **Generate** an API key from your dashboard
4. **Configure** the extension with your API key

## Troubleshooting

### Common Issues

**Agent won't start**
- Verify your API key is correct
- Check internet connectivity
- Ensure VS Code has necessary permissions

**Status bar not showing**
- Restart VS Code
- Check if extension is enabled in Extensions panel
- Verify installation was successful

**Performance issues**
- Adjust agent monitoring frequency in settings
- Disable auto-start if not needed
- Check VS Code developer console for errors

### Getting Help

- **Documentation**: [AgUnblock Docs](https://docs.agunblock.com)
- **Support**: [Contact Support](https://agunblock.com/support)
- **GitHub Issues**: [Report Issues](https://github.com/thegovind/agunblock/issues)

## Requirements

- **Visual Studio Code** 1.74.0 or higher
- **Internet connection** for agent communication
- **AgUnblock API key** (free tier available)

## Privacy & Security

- **Local processing**: Code analysis happens locally when possible
- **Secure transmission**: All API communications use HTTPS
- **No code storage**: Your code is not stored on AgUnblock servers
- **Configurable privacy**: Control what data is shared with agents

## License

This extension is licensed under the MIT License. See the [LICENSE](LICENSE) file for details.

## Contributing

We welcome contributions! Please see our [Contributing Guide](CONTRIBUTING.md) for details.

---

**Enhance your coding experience with AI-powered background agents!**

For more information, visit [AgUnblock.com](https://agunblock.com)
