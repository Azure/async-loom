import * as vscode from 'vscode';

export function activate(context: vscode.ExtensionContext) {
    console.log('AGU Copilot Extension is now active!');

    let listAgentsCommand = vscode.commands.registerCommand('agu.listAgents', () => {
        vscode.window.showInformationMessage('AGU Agents: SWE Agent, SRE Agent, QA Agent, DevOps Agent');
    });

    let selectAgentCommand = vscode.commands.registerCommand('agu.selectAgent', async () => {
        const agents = ['SWE Agent', 'SRE Agent', 'QA Agent', 'DevOps Agent'];
        const selected = await vscode.window.showQuickPick(agents, {
            placeHolder: 'Select an AGU agent'
        });
        
        if (selected) {
            vscode.window.showInformationMessage(`Selected: ${selected}`);
        }
    });

    let assignTaskCommand = vscode.commands.registerCommand('agu.assignTask', async () => {
        const task = await vscode.window.showInputBox({
            placeHolder: 'Enter task description',
            prompt: 'What task would you like to assign to the agent?'
        });
        
        if (task) {
            vscode.window.showInformationMessage(`Task assigned: ${task}`);
        }
    });

    context.subscriptions.push(listAgentsCommand, selectAgentCommand, assignTaskCommand);

    const participant = vscode.chat.createChatParticipant('agu', handleChatRequest);
    participant.iconPath = vscode.Uri.joinPath(context.extensionUri, 'icon.png');
    
    context.subscriptions.push(participant);
}

async function handleChatRequest(
    request: vscode.ChatRequest,
    context: vscode.ChatContext,
    stream: vscode.ChatResponseStream,
    token: vscode.CancellationToken
): Promise<vscode.ChatResult> {
    
    const prompt = request.prompt.toLowerCase();
    
    if (prompt.includes('list') && prompt.includes('agent')) {
        stream.markdown('## Available AGU Agents\n\n');
        stream.markdown('- **Software Engineering Agent**: Code reviews, bug fixes, feature development\n');
        stream.markdown('- **Site Reliability Engineering Agent**: Infrastructure, monitoring, deployments\n');
        stream.markdown('- **Quality Assurance Agent**: Testing, validation, quality checks\n');
        stream.markdown('- **DevOps Agent**: CI/CD pipelines, automation, tooling\n');
        
    } else if (prompt.includes('select') && prompt.includes('agent')) {
        stream.markdown('🤖 **Agent Selection**\n\n');
        stream.markdown('Which agent would you like to select? Available options:\n');
        stream.markdown('- `swe-agent` for Software Engineering tasks\n');
        stream.markdown('- `sre-agent` for Site Reliability Engineering\n');
        stream.markdown('- `qa-agent` for Quality Assurance\n');
        stream.markdown('- `devops-agent` for DevOps tasks\n');
        
    } else if (prompt.includes('assign') && prompt.includes('task')) {
        stream.markdown('📋 **Task Assignment**\n\n');
        stream.markdown('To assign a task, please specify:\n');
        stream.markdown('1. The agent ID (e.g., swe-agent)\n');
        stream.markdown('2. The task description\n');
        stream.markdown('3. Priority level (optional)\n\n');
        stream.markdown('Example: `@agu assign task to swe-agent: review authentication code with high priority`\n');
        
    } else if (prompt.includes('status')) {
        stream.markdown('📊 **Agent Status**\n\n');
        stream.markdown('All agents are currently available and ready for task assignment.\n');
        stream.markdown('Use `@agu list agents` to see available agents.\n');
        
    } else {
        stream.markdown('👋 **Welcome to AGU Copilot Extension!**\n\n');
        stream.markdown('I can help you interact with AGU agents. Try these commands:\n\n');
        stream.markdown('- `@agu list available agents`\n');
        stream.markdown('- `@agu select the SWE agent`\n');
        stream.markdown('- `@agu assign a task to review my code`\n');
        stream.markdown('- `@agu what\'s the status of agents?`\n');
    }
    
    return { metadata: { command: 'agu' } };
}

export function deactivate() {}
