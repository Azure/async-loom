# AGU Copilot Extension

A GitHub Copilot extension that allows users to interact with AGU (Agent Unblock) agents directly from Copilot Chat using the `@agu` command.

## Features

- **Agent Discovery**: List all available AGU agents with their capabilities
- **Agent Selection**: Select specific agents for task assignment
- **Task Assignment**: Assign tasks to agents with priority levels
- **Status Monitoring**: Check agent status and activity

## Available Agents

- **Software Engineering Agent**: Handles code reviews, bug fixes, and development tasks
- **Site Reliability Engineering Agent**: Manages infrastructure, monitoring, and deployment
- **Quality Assurance Agent**: Performs testing, validation, and quality checks
- **DevOps Agent**: Handles CI/CD pipelines, automation, and tooling

## Usage in Copilot Chat

1. **List available agents**:
   ```
   @agu list all available agents
   ```

2. **Select an agent**:
   ```
   @agu select the SWE agent
   ```

3. **Assign a task**:
   ```
   @agu assign a high priority task to review the authentication code
   ```

4. **Check agent status**:
   ```
   @agu what's the status of the SRE agent?
   ```

## Development

### Prerequisites

- Node.js 18+
- npm or yarn

### Setup

```bash
cd copilot-extension
npm install
npm run build
```

### Running locally

```bash
npm run dev
```

The extension will be available at `http://localhost:3000`.

### Building for production

```bash
npm run build
npm start
```

## GitHub App Configuration

To use this extension, you need to:

1. Create a GitHub App with Copilot Extension permissions
2. Configure the app's webhook URL to point to your deployed extension
3. Install the app in your organization or repositories

## Environment Variables

- `PORT`: Server port (default: 3000)
- `GITHUB_APP_ID`: Your GitHub App ID
- `GITHUB_PRIVATE_KEY`: Your GitHub App private key

## License

MIT
