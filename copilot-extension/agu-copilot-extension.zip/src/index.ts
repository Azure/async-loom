import { createServer, type IncomingMessage } from "node:http";
import { verifyAndParseRequest, type CopilotPayload } from "@copilot-extensions/preview-sdk";
import OpenAI from "openai";

const AVAILABLE_AGENTS = [
  {
    id: "swe-agent",
    name: "Software Engineering Agent",
    description: "Handles code reviews, bug fixes, and development tasks",
    capabilities: ["code-review", "bug-fixing", "feature-development", "testing"]
  },
  {
    id: "sre-agent", 
    name: "Site Reliability Engineering Agent",
    description: "Manages infrastructure, monitoring, and deployment tasks",
    capabilities: ["infrastructure", "monitoring", "deployment", "incident-response"]
  },
  {
    id: "qa-agent",
    name: "Quality Assurance Agent", 
    description: "Performs testing, validation, and quality checks",
    capabilities: ["automated-testing", "manual-testing", "quality-assurance", "validation"]
  },
  {
    id: "devops-agent",
    name: "DevOps Agent",
    description: "Handles CI/CD pipelines, automation, and tooling",
    capabilities: ["ci-cd", "automation", "tooling", "pipeline-management"]
  }
];

const functions = [
  {
    name: "listAgents",
    description: "List all available AGU agents",
    parameters: {
      type: "object",
      properties: {},
      required: []
    }
  },
  {
    name: "selectAgent",
    description: "Select a specific AGU agent for task assignment",
    parameters: {
      type: "object", 
      properties: {
        agentId: {
          type: "string",
          description: "The ID of the agent to select",
          enum: AVAILABLE_AGENTS.map(agent => agent.id)
        }
      },
      required: ["agentId"]
    }
  },
  {
    name: "assignTask",
    description: "Assign a task to the selected AGU agent",
    parameters: {
      type: "object",
      properties: {
        agentId: {
          type: "string", 
          description: "The ID of the agent to assign the task to",
          enum: AVAILABLE_AGENTS.map(agent => agent.id)
        },
        task: {
          type: "string",
          description: "The task description to assign to the agent"
        },
        priority: {
          type: "string",
          description: "Task priority level",
          enum: ["low", "medium", "high", "urgent"]
        }
      },
      required: ["agentId", "task"]
    }
  },
  {
    name: "getAgentStatus",
    description: "Get the current status of an AGU agent",
    parameters: {
      type: "object",
      properties: {
        agentId: {
          type: "string",
          description: "The ID of the agent to check status for",
          enum: AVAILABLE_AGENTS.map(agent => agent.id)
        }
      },
      required: ["agentId"]
    }
  }
];

async function handleListAgents(): Promise<string> {
  const agentList = AVAILABLE_AGENTS.map(agent => 
    `**${agent.name}** (${agent.id})\n${agent.description}\nCapabilities: ${agent.capabilities.join(", ")}`
  ).join("\n\n");
  
  return `## Available AGU Agents\n\n${agentList}\n\nUse \`selectAgent\` to choose an agent for task assignment.`;
}

async function handleSelectAgent(agentId: string): Promise<string> {
  const agent = AVAILABLE_AGENTS.find(a => a.id === agentId);
  if (!agent) {
    return `❌ Agent with ID "${agentId}" not found. Use \`listAgents\` to see available agents.`;
  }
  
  return `✅ **${agent.name}** selected!\n\n${agent.description}\n\nCapabilities: ${agent.capabilities.join(", ")}\n\nYou can now use \`assignTask\` to give this agent a task.`;
}

async function handleAssignTask(agentId: string, task: string, priority: string = "medium"): Promise<string> {
  const agent = AVAILABLE_AGENTS.find(a => a.id === agentId);
  if (!agent) {
    return `❌ Agent with ID "${agentId}" not found. Use \`listAgents\` to see available agents.`;
  }
  
  const taskId = `task-${Date.now()}`;
  
  return `🚀 **Task Assigned Successfully!**\n\n**Agent:** ${agent.name}\n**Task:** ${task}\n**Priority:** ${priority}\n**Task ID:** ${taskId}\n\nThe agent will begin working on this task. Use \`getAgentStatus\` to check progress.`;
}

async function handleGetAgentStatus(agentId: string): Promise<string> {
  const agent = AVAILABLE_AGENTS.find(a => a.id === agentId);
  if (!agent) {
    return `❌ Agent with ID "${agentId}" not found. Use \`listAgents\` to see available agents.`;
  }
  
  const statuses = ["idle", "working", "completed", "error"];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
  
  return `📊 **${agent.name} Status**\n\nCurrent Status: ${randomStatus}\nLast Activity: ${new Date().toLocaleString()}\nActive Tasks: ${Math.floor(Math.random() * 5)}\n\nFor detailed task information, check the AGU dashboard.`;
}

const server = createServer(async (request: IncomingMessage, response) => {
  if (request.method === "GET") {
    response.statusCode = 200;
    response.end("OK");
    return;
  }

  const body = await getBody(request);
  
  let verifyAndParseRequestResult: Awaited<ReturnType<typeof verifyAndParseRequest>>;
  const apiKey = request.headers["x-github-token"] as string;
  
  try {
    const signature = request.headers["x-github-public-key-signature"] as string;
    const keyId = request.headers["x-github-public-key-identifier"] as string;
    verifyAndParseRequestResult = await verifyAndParseRequest(body, signature, keyId, {
      token: apiKey,
    });
  } catch (err) {
    console.error("Error verifying request:", err);
    response.statusCode = 401;
    response.end("Unauthorized");
    return;
  }

  const { isValidRequest, payload } = verifyAndParseRequestResult;
  
  if (!isValidRequest) {
    console.error("Request verification failed");
    response.statusCode = 401;
    response.end("Unauthorized");
    return;
  }

  try {
    const openai = new OpenAI({
      apiKey: apiKey,
      baseURL: "https://api.githubcopilot.com",
    });

    const stream = openai.beta.chat.completions.stream({
      model: "gpt-4o",
      messages: payload.messages,
      tools: functions.map(func => ({ type: "function" as const, function: func })),
    });

    response.setHeader("Content-Type", "text/plain; charset=utf-8");
    response.statusCode = 200;

    for await (const chunk of stream) {
      const delta = chunk.choices[0]?.delta;
      
      if (delta?.tool_calls) {
        for (const toolCall of delta.tool_calls) {
          if (toolCall.function?.name && toolCall.function?.arguments) {
            try {
              const args = JSON.parse(toolCall.function.arguments);
              let result = "";
              
              switch (toolCall.function.name) {
                case "listAgents":
                  result = await handleListAgents();
                  break;
                case "selectAgent":
                  result = await handleSelectAgent(args.agentId);
                  break;
                case "assignTask":
                  result = await handleAssignTask(args.agentId, args.task, args.priority);
                  break;
                case "getAgentStatus":
                  result = await handleGetAgentStatus(args.agentId);
                  break;
                default:
                  result = `❌ Unknown function: ${toolCall.function.name}`;
              }
              
              response.write(result);
            } catch (parseError) {
              console.error("Error parsing function arguments:", parseError);
              response.write("❌ Error processing function call");
            }
          }
        }
      } else if (delta?.content) {
        response.write(delta.content);
      }
    }
    
    response.end();
  } catch (error) {
    console.error("Error processing request:", error);
    response.statusCode = 500;
    response.end("Internal Server Error");
  }
});

async function getBody(request: IncomingMessage): Promise<string> {
  return new Promise((resolve) => {
    let body = "";
    request.on("data", (chunk) => {
      body += chunk.toString();
    });
    request.on("end", () => {
      resolve(body);
    });
  });
}

const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`AGU Copilot Extension server running on port ${port}`);
});
